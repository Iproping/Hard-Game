var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var player = createSprite(200, 380, 20, 20);
    player.shapeColor = ("blue");
    
var objective = createSprite(200, 20, 20, 20);
    objective.shapeColor = ("brown");
    
var wall = createSprite(200, 200, 100, 20);
    wall.shapeColor = ("red");

function draw() {
  background("yellow")
  createEdgeSprites()
  
if (keyDown(RIGHT_ARROW)){
    player.velocityX = 2;
    player.velocityY = 0;
  }
    
  if (keyDown(LEFT_ARROW)){
    player.velocityX = -2;
    player.velocityY = 0;
  }
  
  if (keyDown(UP_ARROW)){
    player.velocityX = 0;
    player.velocityY = -2;
  }
    
  if (keyDown(DOWN_ARROW)){
    player.velocityX = 0;
    player.velocityY = 2;
  }
  
  wall.velocityX = player.velocityX
  
  player.bounceOff(edges);
  
      if (player.isTouching(wall))  
{
player.setVelocity(0, 0);
wall.setVelocity(0, 0);
textSize(20);
stroke("red");
text("You got eliminated", 100, 300);
}

      if (player.isTouching(objective))  
{
player.setVelocity(0, 0);
wall.setVelocity(0, 0);
textSize(20);
stroke("red");
text("You won!", 100, 300);
}

  
  
  drawSprites()
  
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
